from flask import Flask, request, abort
from flask import render_template
from flask import make_response

app = Flask(__name__)

@app.route('/<mac_addr>/<count>/', methods=['GET', 'POST'])
def SwitchSetCount(mac_addr, count):
    return make_response(render_template('SwitchSet.html', mac_addr=mac_addr, count=int(count)))

if __name__ == "__main__":
    app.run('127.0.0.1', port=80, threaded=True, use_reloader=False)
